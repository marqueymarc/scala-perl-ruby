#!/usr/bin/perl
#
# Takes the mechanical turk output for blog classification and outputs a 
# line per blog with up to three columns of top voted categories.
#	History:
#		(mm) -- 1/08/09 first version
#

	    $nl = "\n";
	    $line = 1;
	$blog_pos = 26;
	$votes_pos = 27;
	    
      sub cat_sort;
      my %blog, %bvotes;
      while (<>) {
		next if $line++ == 1 || /^$/ || /^#/;
		chomp;
		@row = split ",";
		$blog = $row[$blog_pos];
		$votes = $row[$votes_pos];
		@votes = split /\|/, $votes;
		for $v (@votes) {
			$v =~ s/_/./g if $v !~ /Blog_does_not_exist/i;
			$blogs{$blog}{$v} += 1;
		}
      	}
	print "Blog,SV1, v1, SV2, v2,SV3, v3$nl";

	for $b (sort keys %blogs) {

		@res_votes = ("", "",  "", "", "", "");
		# copy the category/vote 
		%bvotes = %{$blogs{$b}};
		$i = 0;
		for $v (sort cat_sort  (keys %bvotes)) {
			if ($bvotes{$v} > 1) {
				$res_votes[$i++] = $v;
				$res_votes[$i++] = $bvotes{$v};
			}
		}
		print "$b";

		print first three pairs of category/votes
		for ($i=0; $i < 6; $i++) {
			print ",$res_votes[$i]";
		}
		print $nl;
	}
	
	
# sorts subcategories higher than the supercategory, not done tyhis way cause 
# can be inconsistent with regard to comparisons
sub cat_sort {
	#return -1 if $a =~ /^$b\..*/;
	#return +1 if $b =~ /^$a\..*/;
	{$bvotes{$b} <=> $bvotes{$a}}
}
